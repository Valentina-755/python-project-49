### Hexlet tests and linter status:
[![Actions Status](https://github.com/Valentina-755/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Valentina-755/python-project-49/actions)
# asciinema brain-even:
https://asciinema.org/a/EK8osIHsh2fiI0UqwbRcCxqth
# asciinema brain-calc:
https://asciinema.org/a/9sEEpjyi9h6fgMftueRXGXv8D
# asciinema brain-gcd:
 https://asciinema.org/a/eXs9nVu5rDBZp57g24pOsON9j
# asciinema brain-progression:
https://asciinema.org/a/TBjkYUpKsXVHTrAxK3SkAHptI
# asciinema brain-prime:
https://asciinema.org/a/e0YCMEF5Oa8PjcxvTQAc912Jg