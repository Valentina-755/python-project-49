### Hexlet tests and linter status:
[![Actions Status](https://github.com/Valentina-755/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Valentina-755/python-project-49/actions)
# asciinema brain-even:
https://asciinema.org/a/EK8osIHsh2fiI0UqwbRcCxqth
#asciinema brain-calc:
https://asciinema.org/a/9sEEpjyi9h6fgMftueRXGXv8D